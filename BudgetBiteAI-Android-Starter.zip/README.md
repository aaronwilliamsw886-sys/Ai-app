# BudgetBite AI — Android starter project

This is a first native Android prototype for BudgetBite AI. It currently uses a built-in sample recipe collection; it does NOT connect to a live AI model yet.

## Build from your Android phone using GitHub Actions

1. In your phone browser, sign in to GitHub and create a new **public** repository named `BudgetBiteAI` (public keeps GitHub Actions usage simple for a beginner; do not add secrets).
2. Upload the contents of this project to the repository, keeping the folder paths intact. Upload files using GitHub's web interface; the `.github/workflows/build-apk.yml` workflow must be included.
3. Open the repository's **Actions** tab. Select **Build BudgetBite AI APK** and tap **Run workflow**. If prompted, enable Actions for the repository.
4. Wait for the workflow to finish successfully.
5. Open the completed workflow run, find **Artifacts**, and download `BudgetBiteAI-debug-apk`. Extract the ZIP and install `app-debug.apk`.
6. Android may ask you to allow your browser or file manager to install unknown apps. Only install APKs you built or trust.

## Important

- This is a debug APK for testing, not a Play Store release bundle.
- For Google Play, a signed release Android App Bundle (`.aab`), a secure signing key, store listing, privacy declarations, and testing may be needed.
- Sample prices are rough examples, not live Irish supermarket prices. Review them and update them before public release.
- The shopping list combines ingredients but does not calculate package quantities yet.
- Live AI, accounts, subscriptions, payments, and remote data storage are not included.
- Never put an AI API key in the Android source code.
