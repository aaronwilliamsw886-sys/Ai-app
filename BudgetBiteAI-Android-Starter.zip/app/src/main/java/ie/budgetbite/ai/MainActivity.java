package ie.budgetbite.ai;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    final int green = Color.rgb(31, 83, 59);
    final int cream = Color.rgb(250, 247, 238);
    final int ink = Color.rgb(37, 45, 39);
    LinearLayout root, content;
    EditText budgetInput, daysInput, peopleInput, ingredientsInput;
    Spinner dietSpinner;
    TextView status;
    SharedPreferences prefs;

    static class Recipe {
        String name, type, ingredients, method;
        double cost;
        int minutes;
        Recipe(String n, String t, double c, int m, String i, String s) {
            name=n; type=t; cost=c; minutes=m; ingredients=i; method=s;
        }
    }
    final List<Recipe> recipes = Arrays.asList(
        new Recipe("Tomato & chickpea pasta","Vegetarian",1.35,20,"Pasta, tinned tomatoes, chickpeas, onion","Boil pasta. Soften onion, add tomatoes and chickpeas, simmer and combine."),
        new Recipe("Egg fried rice","Vegetarian",1.20,15,"Rice, eggs, frozen peas, soy sauce","Cook rice. Scramble eggs, add peas and rice, then season with soy sauce."),
        new Recipe("Loaded baked potato","Vegetarian",1.40,45,"Potatoes, baked beans, grated cheese","Bake or microwave potato until soft. Split and top with beans and cheese."),
        new Recipe("Peanut butter banana oats","Vegetarian",0.75,5,"Oats, milk, banana, peanut butter","Cook oats with milk. Slice banana on top and add peanut butter."),
        new Recipe("Lentil tomato curry","Vegetarian",1.30,25,"Red lentils, rice, curry powder, tinned tomatoes","Simmer lentils, tomatoes, curry powder and water until soft. Serve with rice."),
        new Recipe("Cheese & bean quesadilla","Vegetarian",1.45,10,"Tortillas, kidney beans, cheese, salsa","Mash beans onto a tortilla, add cheese, fold and toast in a dry pan."),
        new Recipe("Vegetable noodle stir-fry","Vegetarian",1.50,15,"Noodles, frozen vegetables, soy sauce","Cook noodles. Stir-fry vegetables, add noodles and soy sauce."),
        new Recipe("Pesto pasta","Vegetarian",1.65,15,"Pasta, pesto, frozen peas","Boil pasta and peas. Drain, stir through pesto and a little pasta water."),
        new Recipe("Tuna sweetcorn jacket potato","Meat/fish",1.90,45,"Potatoes, tinned tuna, sweetcorn, yoghurt","Bake potato. Mix drained tuna and sweetcorn with yoghurt and spoon on top."),
        new Recipe("Chicken tomato rice","Meat/fish",2.10,25,"Rice, chicken, tinned tomatoes, onion","Cook chicken and onion thoroughly. Add tomatoes and cooked rice; heat through."),
        new Recipe("Sausage tomato pasta","Meat/fish",1.85,20,"Pasta, sausages, tinned tomatoes, onion","Cook sausages fully and slice. Simmer with onion and tomatoes; serve with pasta."),
        new Recipe("Bean chilli rice bowl","Vegetarian",1.40,20,"Rice, kidney beans, tinned tomatoes, chilli powder","Simmer beans, tomatoes and seasoning. Serve over rice."),
        new Recipe("Cheese omelette & toast","Vegetarian",1.10,10,"Eggs, cheese, bread","Beat eggs, cook gently in a pan, add cheese and serve with toast."),
        new Recipe("Creamy mushroom pasta","Vegetarian",1.70,20,"Pasta, mushrooms, milk, flour, garlic","Cook pasta. Fry mushrooms and garlic, stir in milk and a little flour to thicken."),
        new Recipe("Couscous chickpea bowl","Vegetarian",1.35,10,"Couscous, chickpeas, cucumber, lemon","Cover couscous with hot water. Fluff and mix with chickpeas and chopped vegetables.")
    );

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("budgetbite", MODE_PRIVATE);
        showHome();
    }

    int dp(float x) { return (int)(x * getResources().getDisplayMetrics().density); }

    TextView text(String value, int size, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(0, dp(5), 0, dp(5));
        return t;
    }

    void setup(String subtitle) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(cream);
        root.setPadding(dp(18), dp(14), dp(18), dp(14));
        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(8), 0, dp(20));
        TextView brand = text("BudgetBite AI", 27, true, green);
        root.addView(brand);
        root.addView(text(subtitle, 14, false, ink));
        View line = new View(this); line.setBackgroundColor(Color.rgb(218, 224, 211));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
        lp.setMargins(0, dp(8), 0, dp(8)); root.addView(line, lp);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    void button(String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label); b.setAllCaps(false); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(6), 0, dp(6));
        content.addView(b, lp);
        b.setOnClickListener(v -> action.run());
    }

    EditText field(String hint, String value, int inputType) {
        EditText e = new EditText(this);
        e.setSingleLine(true); e.setHint(hint); e.setText(value);
        e.setInputType(inputType); e.setTextColor(ink);
        e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green));
        content.addView(e, new LinearLayout.LayoutParams(-1, -2));
        return e;
    }

    void showHome() {
        setup("Affordable meals for student life in Ireland");
        content.addView(text("Eat well. Spend less.", 23, true, ink));
        content.addView(text("Plan meals around your budget, discover simple recipes and build a shopping list.", 16, false, ink));
        content.addView(text("Your food budget (€)", 15, true, green));
        budgetInput = field("e.g. 25", prefs.getString("budget","25"), 8194);
        content.addView(text("How many days?", 15, true, green));
        daysInput = field("e.g. 5", prefs.getString("days","5"), 2);
        content.addView(text("How many people?", 15, true, green));
        peopleInput = field("e.g. 1", prefs.getString("people","1"), 2);
        content.addView(text("Diet preference", 15, true, green));
        dietSpinner = new Spinner(this);
        String[] diets = {"Any meals", "Vegetarian only"};
        dietSpinner.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, diets));
        dietSpinner.setSelection(prefs.getBoolean("veg", false) ? 1 : 0);
        content.addView(dietSpinner);
        content.addView(text("Ingredients you already have (optional)", 15, true, green));
        ingredientsInput = field("e.g. rice, eggs, potatoes", prefs.getString("ingredients",""), 1);
        button("Build my meal plan", () -> makePlan());
        button("Browse all recipes", () -> showRecipes());
        button("Shopping list", () -> showShoppingList());
        content.addView(text("Recipe prices are rough estimates, not live supermarket prices. Always check allergen labels.", 12, false, Color.DKGRAY));
    }

    int safeInt(EditText e, int fallback, int min, int max) {
        try { return Math.max(min, Math.min(max, Integer.parseInt(e.getText().toString().trim()))); }
        catch(Exception ex) { return fallback; }
    }
    double safeDouble(EditText e, double fallback) {
        try { return Math.max(1, Math.min(500, Double.parseDouble(e.getText().toString().trim().replace(",", ".")))); }
        catch(Exception ex) { return fallback; }
    }

    void makePlan() {
        double budget = safeDouble(budgetInput,25);
        int days = safeInt(daysInput,5,1,14);
        int people = safeInt(peopleInput,1,1,8);
        boolean veg = dietSpinner.getSelectedItemPosition()==1;
        String existing = ingredientsInput.getText().toString().trim();
        prefs.edit().putString("budget",String.valueOf(budget))
            .putString("days",String.valueOf(days)).putString("people",String.valueOf(people))
            .putBoolean("veg",veg).putString("ingredients",existing).apply();

        List<Recipe> pool = new ArrayList<>();
        for(Recipe r:recipes) if(!veg || r.type.equals("Vegetarian")) pool.add(r);
        List<Recipe> plan = new ArrayList<>();
        // Rotate a variety of meals; daily cost estimates assume one serving per recipe.
        for(int i=0;i<days*3;i++) plan.add(pool.get(i % pool.size()));
        double total = 0;
        for(Recipe r:plan) total += r.cost * people;
        setup("Your sample meal plan");
        content.addView(text(String.format(Locale.UK,"Budget: €%.2f  •  %d days  •  %d person(s)",budget,days,people),16,true,green));
        content.addView(text(String.format(Locale.UK,"Estimated recipe cost: €%.2f",total),18,true,ink));
        if(total > budget) content.addView(text("This plan may exceed your budget. Try fewer meals, fewer people or a higher budget. Costs are estimates.",14,true,Color.rgb(150,70,25)));
        else content.addView(text(String.format(Locale.UK,"Estimated budget remaining: €%.2f",budget-total),14,true,green));
        if(!existing.isEmpty()) content.addView(text("Ingredients you said you have: "+existing+". Review each recipe and remove anything you don't need from your shopping list.",13,false,ink));
        for(int d=0; d<days; d++) {
            content.addView(text("DAY "+(d+1),19,true,green));
            for(int m=0;m<3;m++) {
                Recipe r=plan.get(d*3+m);
                content.addView(text(new String[]{"Breakfast","Lunch","Dinner"}[m]+": "+r.name,16,true,ink));
                content.addView(text(String.format(Locale.UK,"€%.2f per serving • %d min",r.cost,r.minutes),13,false,Color.DKGRAY));
                content.addView(text("Ingredients: "+r.ingredients,14,false,ink));
            }
        }
        button("View recipes & instructions", () -> showRecipes());
        button("Create shopping list", () -> savePlanAndShopping(plan, people));
        button("Back to home", () -> showHome());
    }

    void showRecipes() {
        setup("Affordable student recipes");
        for(Recipe r:recipes) {
            content.addView(text(r.name,18,true,green));
            content.addView(text(r.type+" • "+String.format(Locale.UK,"€%.2f per serving",r.cost)+" • "+r.minutes+" min",13,false,Color.DKGRAY));
            content.addView(text("Ingredients: "+r.ingredients,14,false,ink));
            content.addView(text("Method: "+r.method,14,false,ink));
            View line = new View(this); line.setBackgroundColor(Color.LTGRAY);
            content.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
        }
        button("Back to home", () -> showHome());
    }

    void savePlanAndShopping(List<Recipe> plan, int people) {
        StringBuilder list = new StringBuilder();
        LinkedHashSet<String> items = new LinkedHashSet<>();
        for(Recipe r:plan) for(String item:r.ingredients.split(",")) items.add(item.trim());
        for(String item:items) list.append("□ ").append(item).append("\n");
        prefs.edit().putString("shopping",list.toString()).putInt("shoppingPeople",people).apply();
        showShoppingList();
    }

    void showShoppingList() {
        setup("Your shopping list");
        String saved = prefs.getString("shopping","");
        if(saved.isEmpty()) {
            content.addView(text("You haven't created a list yet. Build a meal plan first.",16,false,ink));
        } else {
            content.addView(text("Ingredients used in your selected sample plan:",16,true,green));
            for(String line:saved.split("\n")) {
                if(line.trim().isEmpty()) continue;
                CheckBox cb = new CheckBox(this);
                cb.setText(line.replace("□ ","")); cb.setTextColor(ink);
                content.addView(cb);
            }
            content.addView(text("This is a combined ingredient list, not exact package quantities. Check recipes and quantities before shopping.",12,false,Color.DKGRAY));
        }
        button("Back to home", () -> showHome());
    }
}
